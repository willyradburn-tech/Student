/* Browser behaviour: the matcher, search, and "fits you" badges.
   Answers are kept in this browser only (localStorage) so they follow you
   from the home page to entry pages. Nothing is sent anywhere. */
(function () {
  var Hub = window.Hub, DATA = window.HUB_DATA;
  if (!Hub || !DATA) return;
  var STORE = "sch-profile-v1";
  var host = document.querySelector("[data-page]") || document.body;
  var page = host.getAttribute("data-page");
  var prefix = host.getAttribute("data-prefix") || "";
  var byId = {};
  DATA.entries.forEach(function (e) { byId[e.id] = e; });
  var catName = {};
  DATA.cats.forEach(function (c) { catName[c.id] = c.name; });

  function loadProfile() {
    var p = Hub.blankProfile();
    try {
      var saved = JSON.parse(localStorage.getItem(STORE) || "{}");
      Object.keys(p).forEach(function (k) { if (saved[k] !== undefined) p[k] = saved[k]; });
    } catch (err) { /* storage unavailable: start blank */ }
    return p;
  }
  function saveProfile(p) {
    try { localStorage.setItem(STORE, JSON.stringify(p)); } catch (err) { /* ignore */ }
  }
  function $(id) { return document.getElementById(id); }

  var STATUS_ORDER = { verified: 0, rechecking: 0, unverified: 1 };
  var VERDICT_ORDER = { yes: 0, maybe: 1, no: 2 };
  function sortItems(items, any) {
    return items.sort(function (a, b) {
      return (STATUS_ORDER[a.e.status] - STATUS_ORDER[b.e.status]) ||
        (any ? VERDICT_ORDER[a.v] - VERDICT_ORDER[b.v] : 0) ||
        a.e.name.localeCompare(b.e.name);
    });
  }

  /* ---------- Home: matcher + search + grouped results ---------- */
  function initHome() {
    var form = $("matcher"), results = $("results"), q = $("q");
    var profile = loadProfile();

    Hub.QUESTIONS.forEach(function (qq) {
      var el = $("f-" + qq.key); if (!el) return;
      el.value = profile[qq.key] == null ? "" : profile[qq.key];
      el.addEventListener(qq.type === "number" ? "input" : "change", function () {
        if (qq.type === "number") {
          var n = parseInt(el.value, 10);
          profile[qq.key] = isNaN(n) ? null : n;
        } else profile[qq.key] = el.value;
        saveProfile(profile); render();
      });
    });
    $("reset").addEventListener("click", function () {
      profile = Hub.blankProfile(); saveProfile(profile);
      Hub.QUESTIONS.forEach(function (qq) { var el = $("f-" + qq.key); if (el) el.value = ""; });
      render();
    });
    form.addEventListener("submit", function (ev) { ev.preventDefault(); });

    var PER_GROUP = 6, expanded = {};
    var searchIndex = {};
    DATA.entries.forEach(function (e) { searchIndex[e.id] = Hub.searchText(e, catName[e.category]); });
    q.addEventListener("input", render);
    $("search-form").addEventListener("submit", function (ev) { ev.preventDefault(); results.scrollIntoView({ block: "start" }); });

    function render() {
      var any = Hub.answeredCount(profile) > 0;
      var terms = q.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
      var tally = { yes: 0, maybe: 0, no: 0 }, shown = 0;
      var groups = {}, notForYou = [];

      DATA.entries.forEach(function (e) {
        if (terms.length && !terms.every(function (t) { return searchIndex[e.id].indexOf(t) >= 0; })) return;
        var v = Hub.evaluate(e, profile);
        shown++;
        if (any) tally[v]++;
        if (any && v === "no") { notForYou.push({ e: e, v: v }); return; }
        (groups[e.category] = groups[e.category] || []).push({ e: e, v: v });
      });

      var tl = $("tally");
      if (any) {
        tl.innerHTML = "<b>" + tally.yes + "</b> likely for you, <b>" + tally.maybe + "</b> might apply, " + tally.no + " probably not.";
      } else {
        tl.textContent = "Answer any question to sort the list. Skip anything you're not sure about.";
      }

      var html = "";
      if (terms.length) {
        html += '<p class="search-note" role="status">' + (shown ? shown + (shown === 1 ? " result" : " results") + " for “" + Hub.esc(q.value.trim()) + "”" : "Nothing matches “" + Hub.esc(q.value.trim()) + "”. Try a broader word, like rent, laptop or fares.") + ' <button type="button" class="linkish" id="clear-q">Clear search</button></p>';
      }
      /* Long groups show their best matches first, with a button for the rest. */
      function cardsWithMore(key, items, verdicts) {
        var limit = expanded[key] ? items.length : PER_GROUP;
        var out = '<div class="cards">' + items.slice(0, limit).map(function (x) { return Hub.cardHTML(x.e, prefix, verdicts ? x.v : null); }).join("") + "</div>";
        if (items.length > limit) out += '<button type="button" class="show-more" data-key="' + key + '">Show all ' + items.length + '</button>';
        return out;
      }
      DATA.cats.forEach(function (c) {
        var items = groups[c.id];
        if (!items || !items.length) return;
        sortItems(items, any);
        html += '<section class="group" id="g-' + c.id + '" aria-labelledby="h-' + c.id + '">' +
          '<div class="group-head"><h2 id="h-' + c.id + '">' + Hub.esc(c.name) + ' <span class="ct">' + items.length + '</span></h2>' +
          '<a class="more" href="' + prefix + 'category/' + c.id + '.html" aria-label="View all in ' + Hub.esc(c.name) + '">View all</a></div>' +
          cardsWithMore(c.id, items, any) + "</section>";
      });
      if (notForYou.length) {
        sortItems(notForYou, any);
        html += '<details class="later" id="later"><summary>Probably not for you <span class="ct">' + notForYou.length + '</span></summary>' +
          '<p class="gn">Based on your answers. Open one to read the rules for yourself.</p>' +
          cardsWithMore("__later", notForYou, true) + "</details>";
      }
      var wasOpen = $("later") && $("later").open;
      results.innerHTML = html;
      if (wasOpen && $("later")) $("later").open = true;
      var cq = $("clear-q");
      if (cq) cq.addEventListener("click", function () { q.value = ""; render(); q.focus(); });
      Array.prototype.forEach.call(results.querySelectorAll(".show-more"), function (b) {
        b.addEventListener("click", function () {
          var key = b.getAttribute("data-key"), count = b.textContent;
          expanded[key] = true; render();
          var next = results.querySelector('[data-key="' + key + '"]');
          if (!next) { var g = $(key === "__later" ? "later" : "g-" + key); if (g) { var cards = g.querySelectorAll(".card h3 a"); if (cards[PER_GROUP]) cards[PER_GROUP].focus(); } }
        });
      });
    }
    render();
  }

  /* ---------- Category page: add fit badges and reorder ---------- */
  function initCategory() {
    var profile = loadProfile();
    var any = Hub.answeredCount(profile) > 0;
    var list = $("list"); if (!list) return;
    var items = Array.prototype.map.call(list.querySelectorAll(".card"), function (node) {
      var e = byId[node.getAttribute("data-id")];
      return { e: e, v: Hub.evaluate(e, profile) };
    });
    sortItems(items, any);
    list.innerHTML = items.map(function (x) { return Hub.cardHTML(x.e, prefix, any ? x.v : null); }).join("");
    var note = $("fit-note");
    if (note && any) note.hidden = false;
  }

  /* ---------- Entry page: say whether it fits, from saved answers ---------- */
  function initEntry() {
    var box = $("fit"); if (!box) return;
    var e = byId[box.getAttribute("data-id")]; if (!e) return;
    var profile = loadProfile();
    if (!Hub.answeredCount(profile)) return;
    var v = Hub.evaluate(e, profile);
    var words = { yes: "Likely for you", maybe: "Might apply to you", no: "Probably not for you" }[v];
    box.innerHTML = Hub.verdictBadge(v) + '<span>' + words + ', based on the answers you gave. <a href="' + prefix + 'index.html#matcher">Change your answers</a></span>';
    box.hidden = false;
  }

  /* ---------- Report form: preselect the entry from ?entry= ---------- */
  function initReport() {
    var sel = $("r-entry"); if (!sel) return;
    var m = /[?&]entry=([a-z0-9-]+)/.exec(window.location.search);
    if (m && byId[m[1]]) sel.value = m[1];
  }

  if (page === "home") initHome();
  else if (page === "report") initReport();
  else if (page === "category") initCategory();
  else if (page === "entry") initEntry();
})();

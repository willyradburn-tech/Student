/* Shared by the build (Node) and the browser: matching rules and card markup.
   Keeping one copy means the pages the build writes and the pages the browser
   redraws always look and behave the same. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.Hub = factory();
})(typeof self !== "undefined" ? self : this, function () {
  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  function fmtDate(iso) {
    if (!iso) return "";
    var p = String(iso).split("-");
    return parseInt(p[2], 10) + " " + MONTHS[parseInt(p[1], 10) - 1] + " " + p[0];
  }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  var STATES = [["qld", "Queensland"], ["nsw", "New South Wales"], ["vic", "Victoria"], ["wa", "Western Australia"], ["act", "ACT"], ["other", "SA, Tasmania or NT"]];

  /* The questions the matcher asks. Order here is the order on the page.
     "state" is where you live (state rebates, regional NSW cards); "campus" is
     where you study (city transport concessions follow the campus). */
  var QUESTIONS = [
    { key: "state", label: "Which state do you live in?", options: STATES },
    { key: "campus", label: "Which state is your campus in?", options: STATES },
    { key: "age", label: "Your age", type: "number" },
    { key: "load", label: "Study load", options: [["full", "Full-time"], ["part", "Part-time"]] },
    { key: "res", label: "Residency", options: [["citizen", "Australian citizen"], ["pr", "Permanent resident"], ["intl", "International student"]] },
    { key: "uni", label: "Your university", options: [["qut", "QUT"], ["uq", "University of Queensland"], ["griffith", "Griffith University"], ["scu", "Southern Cross University"], ["other", "Another uni"]] },
    { key: "field", label: "What are you studying?", options: [["engineering", "Engineering"], ["it", "IT or computing"], ["business", "Business, accounting or finance"], ["care", "Teaching, nursing, midwifery or social work"], ["other", "Something else"]] },
    { key: "payment", label: "Do you get Youth Allowance, Austudy or ABSTUDY?", options: [["yes", "Yes"], ["no", "No"]] },
    { key: "away", label: "Did you move away from home to study?", options: [["yes", "Yes"], ["no", "No"]] },
    { key: "prac", label: "Doing a mandatory placement this year?", options: [["yes", "Yes"], ["no", "No"]] },
    { key: "atsi", label: "Aboriginal or Torres Strait Islander", skip: "Prefer not to say", options: [["yes", "Yes"], ["no", "No"]] }
  ];

  function blankProfile() {
    var p = {};
    QUESTIONS.forEach(function (q) { p[q.key] = q.type === "number" ? null : ""; });
    return p;
  }

  function answeredCount(p) {
    var n = 0;
    QUESTIONS.forEach(function (q) {
      var v = p[q.key];
      if (v !== null && v !== "" && v !== undefined) n++;
    });
    return n;
  }

  /* Each entry's "match" object lists conditions. A blank answer never rules
     anything out; it makes the result "maybe". Rules:
       age: { min, max }                    outside the range -> no
       key: { yes: [...], maybe: [...] }    in yes -> yes, in maybe -> maybe, otherwise no
       key: { no: [...] }                   in no -> no, otherwise yes
     Any "no" wins, then any "maybe". An entry's "cap" can hold the best
     result at "maybe" when eligibility depends on something we don't ask,
     and any entry not marked verified is held at "maybe" too. */
  function evaluate(entry, p) {
    var m = entry.match || {};
    var result = "yes";
    Object.keys(m).forEach(function (key) {
      var cond = m[key], v = p[key], r;
      if (v === null || v === "" || v === undefined) r = "maybe";
      else if (key === "age") {
        r = (cond.min != null && v < cond.min) || (cond.max != null && v > cond.max) ? "no" : "yes";
      } else if (cond.yes || cond.maybe) {
        r = (cond.yes || []).indexOf(v) >= 0 ? "yes" : (cond.maybe || []).indexOf(v) >= 0 ? "maybe" : "no";
      } else if (cond.no) {
        r = cond.no.indexOf(v) >= 0 ? "no" : "yes";
      } else r = "maybe";
      if (r === "no") result = "no";
      else if (r === "maybe" && result === "yes") result = "maybe";
    });
    if (entry.cap === "maybe" && result === "yes") result = "maybe";
    /* Never say "Likely" about an entry we couldn't fully confirm. */
    if (entry.status !== "verified" && result === "yes") result = "maybe";
    return result;
  }

  var STATUS = {
    verified: { cls: "ver", text: function (e) { return "Verified " + fmtDate(e.verified); } },
    rechecking: { cls: "re", text: function () { return "Being rechecked"; } },
    unverified: { cls: "un", text: function () { return "Not confirmed yet"; } }
  };

  function statusBadge(e) {
    var s = STATUS[e.status] || STATUS.unverified;
    return '<span class="badge ' + s.cls + '">' + esc(s.text(e)) + "</span>";
  }

  function verdictBadge(v) {
    if (v === "yes") return '<span class="badge yes">Likely for you</span>';
    if (v === "maybe") return '<span class="badge maybe">Might apply</span>';
    if (v === "no") return '<span class="badge no">Probably not</span>';
    return "";
  }

  /* prefix: path back to the site root from the page the card sits on ("" or "../"). */
  function cardHTML(e, prefix, verdict) {
    return (
      '<article class="card" data-id="' + esc(e.id) + '">' +
        '<div class="card-top">' +
          '<span class="prov">' + esc(e.provider) + "</span>" +
          '<span class="badges">' + verdictBadge(verdict) + statusBadge(e) + (e.draft ? '<span class="badge draft">Draft</span>' : "") + "</span>" +
        "</div>" +
        '<h3><a href="' + prefix + "entry/" + esc(e.id) + '.html">' + esc(e.name) + "</a></h3>" +
        '<p class="sum">' + esc(e.summary) + "</p>" +
        (e.key ? '<p class="keyline">' + esc(e.key) + "</p>" : "") +
      "</article>"
    );
  }

  function searchText(e, catName) {
    return [e.name, e.provider, e.summary, e.key || "", catName || "", (e.tags || []).join(" ")].join(" ").toLowerCase();
  }

  return {
    fmtDate: fmtDate, esc: esc, QUESTIONS: QUESTIONS, blankProfile: blankProfile,
    answeredCount: answeredCount, evaluate: evaluate, cardHTML: cardHTML,
    statusBadge: statusBadge, verdictBadge: verdictBadge, searchText: searchText
  };
});
